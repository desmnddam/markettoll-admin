import React from 'react'
import UserInfo from '../components/UserDetails/UserInfo'
import { useLocation } from 'react-router-dom'
const UserDetails = () => {


  return (
    <div className=''>
      <UserInfo  />
    </div>
  )
}

export default UserDetails
