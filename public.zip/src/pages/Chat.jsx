import React from 'react'
import ChatUIComponent from '../components/Chat/Chat'

export default function Chat() {
  return (
    <div>
        <ChatUIComponent/>
    </div>
  )
}
