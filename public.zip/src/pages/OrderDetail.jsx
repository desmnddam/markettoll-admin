import React from 'react'
import DetailOrder from '../components/OrderDetail/OrderDetail'

export default function OrderDetail() {
  return (
    <div>
        <DetailOrder/>
    </div>
  )
}
