import React from 'react'
import ReportInformation from '../components/ReportDetails/ReportInformation'

const ReportDetails = () => {
  return (
    <div>
      <ReportInformation/>
    </div>
  )
}

export default ReportDetails
