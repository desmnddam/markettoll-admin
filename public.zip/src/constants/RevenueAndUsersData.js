export const RevenueAndUsersData = [
  {
    name: "Jan",
    Revenue: 4000,
    Users: 2400,
    amt: 2400,
  },
  {
    name: "Feb",
    Revenue: 3000,
    Users: 1398,
    amt: 2210,
  },
  {
    name: "Mar",
    Revenue: 2000,
    Users: 3800,
    amt: 2290,
  },
  {
    name: "Apr",
    Revenue: 2780,
    Users: 3908,
    amt: 2000,
  },
  {
    name: "May",
    Revenue: 1890,
    Users: 4800,
    amt: 2181,
  },
  {
    name: "Jun",
    Revenue: 2390,
    Users: 3800,
    amt: 2500,
  },
  {
    name: "Jul",
    Revenue: 3490,
    Users: 4300,
    amt: 2100,
  },
  {
    name: "Aug",
    Revenue: 2490,
    Users: 1300,
    amt: 2100,
  },
  {
    name: "Sep",
    Revenue: 3890,
    Users: 5300,
    amt: 2100,
  },
  {
    name: "Oct",
    Revenue: 3490,
    Users: 4900,
    amt: 2100,
  },
  {
    name: "Nov",
    Revenue: 3490,
    Users: 4300,
    amt: 2100,
  },
  {
    name: "Dec",
    Revenue: 3490,
    Users: 4300,
    amt: 2100,
  },
];
