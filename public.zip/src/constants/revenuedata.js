




export const revenuedata = [
  {
    name: "Jan",
    // uv: 4000,
    Revenue: 2400,
    
  },
  {
    name: "Feb",
    // uv: 3000,
    Revenue: 1398,
    
  },
  {
    name: "Mar",
    // uv: 2000,
    Revenue: 9800,
    
  },
  {
    name: "Apr",
    // uv: 2780,
    Revenue: 3908,
    
  },
  {
    name: "May",
    // uv: 1890,
    Revenue: 4800,
    
  },
  {
    name: "Jun",
    // uv: 2390,
    Revenue: 3800,
    
  },
  {
    name: "Jul",
    // uv: 3490,
    Revenue: 4300,
    
  },
  {
    name: "Aug",
    // uv: 3490,
    Revenue: 4300,
    
  },
  {
    name: "Sep",
    // uv: 3490,
    Revenue: 4300,
    
  },
  {
    name: "Oct",
    // uv: 3490,
    Revenue: 4300,
    
  },
  {
    name: "Nov",
    // uv: 3490,
    Revenue: 4300,
    
  },
  {
    name: "Dec",
    // uv: 3490,
    Revenue: 4300,
    
  },
];
