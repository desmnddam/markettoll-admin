const BASE_URL="https://backend.markettoll.com/api/v1/";


export default BASE_URL;