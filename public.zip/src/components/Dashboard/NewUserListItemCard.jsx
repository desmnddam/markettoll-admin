import React from 'react'

const NewUserListItemCard = () => {
  return (
    <div className='w-full'>
      
    </div>
  )
}

export default NewUserListItemCard
