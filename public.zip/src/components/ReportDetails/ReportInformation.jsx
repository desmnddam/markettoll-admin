import React from 'react'

const ReportInformation = () => {
  return (
    <div>
      <h1 className='text-xl font-bold'>Report Details</h1>
    </div>
  )
}

export default ReportInformation
