import Logo from "./logo2.png";
import LoginImage from "./login.png";
import OTPMockup from "./otp-mockup2.png";
import EmailVerificationMockup from "./email-verification.png";
import ResetPasswordMockup from "./reset-password.png"

export { Logo, LoginImage, OTPMockup, EmailVerificationMockup, ResetPasswordMockup };
